// Verify.ge-ს ინტეგრაციის ტესტი ყალბი (mock) სერვერით: რეალურ SMS-ს არ აგზავნის
const os = require('os'), path = require('path'), fs = require('fs'), http = require('http');
const test = require('node:test'), assert = require('node:assert/strict');
const dbFile = path.join(os.tmpdir(), `vg-${process.pid}.sqlite`);
const sent = [], verifies = [];
let mock, mockUrl, server, base;
const mockCode = '482913';

test.before(async () => {
  mock = http.createServer((req, res) => {
    let body = ''; req.on('data', (c) => (body += c));
    req.on('end', () => {
      const j = body ? JSON.parse(body) : {};
      const json = (st, o) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      if (req.headers.authorization !== 'Bearer test-key') return json(401, { error: 'bad key' });
      if (req.url === '/api/v1/otp/send') { sent.push({ ...j, idem: req.headers['x-idempotency-key'] }); return json(200, { requestId: 'req_' + sent.length, expiresAt: new Date(Date.now() + 3e5).toISOString() }); }
      if (req.url === '/api/v1/otp/verify') { verifies.push(j); return j.code === mockCode ? json(200, { success: true }) : json(400, { success: false, message: 'invalid' }); }
      json(404, {});
    });
  });
  await new Promise((r) => mock.listen(0, r));
  mockUrl = `http://127.0.0.1:${mock.address().port}`;
  Object.assign(process.env, { DB_FILE: dbFile, NODE_ENV: 'test', APP_SECRET: 'test-secret-1234567890', IP_LIMIT: '1000', LOGIN_LIMIT: '1000', SMS_IP_DAILY: '1000',
    SMS_PROVIDER: 'verifyge', VERIFYGE_URL: mockUrl + '/', VERIFYGE_API_KEY: 'test-key' });
  delete process.env.DEV_SHOW_CODE;
  const app = require('./server');
  await new Promise((r) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; r(); }); });
});
test.after(() => { server.close(); mock.close(); for (const f of fs.readdirSync(os.tmpdir())) if (f.startsWith(`vg-${process.pid}`)) fs.unlinkSync(path.join(os.tmpdir(), f)); fs.rmSync(path.join(os.tmpdir(), 'uploads'), { recursive: true, force: true }); setTimeout(() => process.exit(0), 50); });

const post = async (url, body) => { const r = await fetch(base + url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); let d = {}; try { d = await r.json(); } catch (_) {} return { status: r.status, d }; };
const reg = (phone) => ({ role: 'user', name: 'ტესტი', phone, location: 'თბილისი', password: 'Passw0rd-test' });

test('Verify.ge: კოდს პროვაიდერი აგზავნის და ამოწმებს, ჩვენ არ ვქმნით და არ ვინახავთ', async () => {
  const r = await post('/api/auth/register', reg('599880001'));
  assert.equal(r.status, 200); assert.equal(r.d.devCode, undefined);
  assert.equal(sent.length, 1); assert.equal(sent[0].phoneNumber, '+995599880001'); assert.equal(sent[0].channel, 'SMS'); assert.ok(sent[0].idem);
  const row = new (require('better-sqlite3'))(dbFile).prepare('SELECT code_hash FROM codes').get();
  assert.equal(row.code_hash, 'vg:req_1');
  const bad = await post('/api/auth/register-verify', { phone: '599880001', code: '111111' });
  assert.equal(bad.status, 400); assert.match(bad.d.error, /არასწორია/);
  const ok = await post('/api/auth/register-verify', { phone: '599880001', code: mockCode });
  assert.equal(ok.status, 200);
  assert.deepEqual(verifies.map((v) => v.requestId), ['req_1', 'req_1']);
});

test('Verify.ge: 5 მცდარი ცდის შემდეგ ბლოკი ჩვენს მხარესაც მოქმედებს', async () => {
  await post('/api/auth/register', reg('599880002'));
  for (let i = 0; i < 5; i++) assert.equal((await post('/api/auth/register-verify', { phone: '599880002', code: '000000' })).status, 400);
  assert.equal((await post('/api/auth/register-verify', { phone: '599880002', code: mockCode })).status, 429);
});

test('Verify.ge: მხოლოდ ქართული ნომერი გადაეცემა პროვაიდერს', async () => {
  const before = sent.length;
  assert.equal((await post('/api/auth/register', reg('+4915112345678'))).status, 400);
  assert.equal(sent.length, before);
});
