// გასაღების გარეშე ასისტენტი გამორთულია და გარე სერვისს არ იძახებს
const os = require('os'), path = require('path'), fs = require('fs');
const test = require('node:test'), assert = require('node:assert/strict');
const dbFile = path.join(os.tmpdir(), `aioff-${process.pid}.sqlite`);
let server, base;
test.before(async () => {
  Object.assign(process.env, { DB_FILE: dbFile, NODE_ENV: 'test', APP_SECRET: 'test-secret-1234567890' }); delete process.env.ANTHROPIC_API_KEY;
  const app = require('./server'); await new Promise((r) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; r(); }); });
});
test.after(() => { server.close(); for (const f of fs.readdirSync(os.tmpdir())) if (f.startsWith(`aioff-${process.pid}`)) fs.unlinkSync(path.join(os.tmpdir(), f)); fs.rmSync(path.join(os.tmpdir(), 'uploads'), { recursive: true, force: true }); setTimeout(() => process.exit(0), 50); });
test('გასაღების გარეშე: გამორთულია', async () => {
  assert.equal((await (await fetch(base + '/api/assistant/status')).json()).enabled, false);
  const r = await fetch(base + '/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'hi' }] }) });
  assert.equal(r.status, 503);
});
