#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js was not found. Install the LTS version from https://nodejs.org and run this file again."
  read -p "Press Enter to close"; exit 1
fi
if [ ! -d node_modules ]; then
  echo "Installing, please wait..."
  npm install || { echo "Install failed. Send me the text above."; read -p "Press Enter to close"; exit 1; }
fi
echo
echo "Open Chrome and go to:  http://localhost:3000"
echo "Keep this window open while you use the site. Press Ctrl+C to stop."
echo
( sleep 2; open http://localhost:3000 ) &
DEV_SHOW_CODE=1 node server.js
