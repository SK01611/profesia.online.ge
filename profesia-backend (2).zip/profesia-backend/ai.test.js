// AI ასისტენტის ტესტი ყალბი Anthropic სერვერით (რეალურ API-ს არ იძახებს, ფულს არ ხარჯავს)
const os = require('os'), path = require('path'), fs = require('fs'), http = require('http');
const test = require('node:test'), assert = require('node:assert/strict');
const dbFile = path.join(os.tmpdir(), `ai-${process.pid}.sqlite`);
const calls = []; let reply = 'გირჩევთ ბარბერს.\nPROFESSION: ბარბერი\nLOCATION: თბილისი';
let mock, server, base;
test.before(async () => {
  mock = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c));
    req.on('end', () => { calls.push({ headers: req.headers, url: req.url, body: JSON.parse(b) }); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ content: [{ type: 'text', text: reply }] })); });
  });
  await new Promise((r) => mock.listen(0, r));
  Object.assign(process.env, { DB_FILE: dbFile, NODE_ENV: 'test', DEV_SHOW_CODE: '1', APP_SECRET: 'test-secret-1234567890', IP_LIMIT: '1000', LOGIN_LIMIT: '1000', SMS_IP_DAILY: '100000',
    ANTHROPIC_API_KEY: 'sk-test-key', ANTHROPIC_BASE_URL: `http://127.0.0.1:${mock.address().port}`, AI_GUEST_DAILY: '3', AI_USER_DAILY: '5', AI_GLOBAL_DAILY: '100' });
  const app = require('./server');
  await new Promise((r) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; r(); }); });
});
test.after(() => { server.close(); mock.close(); for (const f of fs.readdirSync(os.tmpdir())) if (f.startsWith(`ai-${process.pid}`)) fs.unlinkSync(path.join(os.tmpdir(), f)); fs.rmSync(path.join(os.tmpdir(), 'uploads'), { recursive: true, force: true }); setTimeout(() => process.exit(0), 50); });

const jar = () => { const m = new Map(); return m; };
async function call(method, url, body, cookies) {
  const cookie = cookies ? [...cookies].map(([k, v]) => `${k}=${v}`).join('; ') : '';
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  if (cookies) for (const sc of r.headers.getSetCookie()) { const [kv] = sc.split(';'); const i = kv.indexOf('='); cookies.set(kv.slice(0, i), kv.slice(i + 1)); }
  let d = {}; try { d = await r.json(); } catch (_) {}
  return { status: r.status, d };
}
async function reg(phone, extra) {
  const c = jar();
  const r = await call('POST', '/api/auth/register', { role: 'user', name: 'ტესტი', phone, location: 'თბილისი', password: 'Passw0rd-test', ...extra }, c);
  assert.equal(r.status, 200, JSON.stringify(r.d));
  const v = await call('POST', '/api/auth/register-verify', { phone, code: r.d.devCode }, c); assert.equal(v.status, 200);
  return c;
}
const PRO = (prof) => ({ role: 'professional', profession: prof, age: 30, experience: '5 წელი', priceMode: 'negotiable' });
const ask = (text, cookies) => call('POST', '/api/assistant', { messages: [{ role: 'user', content: text }] }, cookies);

test('ასისტენტი ჩართულია გასაღებით; პასუხში მხოლოდ რეალური პროფესიონალები ბრუნდება; ტელეფონი მოდელს არ ეგზავნება', async () => {
  await reg('599660001', PRO('ბარბერი')); await reg('599660002', PRO('ელექტრიკოსი'));
  assert.equal((await call('GET', '/api/assistant/status')).d.enabled, true);
  const r = await ask('თმის შეჭრა მჭირდება თბილისში');
  assert.equal(r.status, 200);
  assert.equal(r.d.matches.length, 1); assert.equal(r.d.matches[0].profession, 'ბარბერი');
  assert.equal(JSON.stringify(r.d).includes('PROFESSION:'), false);
  const c = calls[calls.length - 1];
  assert.equal(c.headers['x-api-key'], 'sk-test-key'); assert.equal(c.body.model, 'claude-haiku-5-5'); assert.ok(c.body.max_tokens <= 500);
  assert.match(c.body.system, /ბარბერი \(1\)/); assert.match(c.body.system, /ელექტრიკოსი \(1\)/);
  assert.equal(JSON.stringify(c.body).includes('599660001'), false);
});

test('ასისტენტი: გამოგონილი ან მავნე პროფესია არ იძლევა შედეგს; ცუდი შეყვანა უარყოფილია', async () => {
  reply = 'კარგი.\nPROFESSION: ადმინისტრატორი\nLOCATION: NONE';
  const c = jar();
  const r = await ask('გამარჯობა', c); assert.equal(r.status, 200); assert.deepEqual(r.d.matches, []);
  assert.equal((await call('POST', '/api/assistant', { messages: [] }, c)).status, 400);
  assert.equal((await call('POST', '/api/assistant', { messages: [{ role: 'assistant', content: 'x' }] }, c)).status, 400);
  reply = 'გირჩევთ ბარბერს.\nPROFESSION: ბარბერი\nLOCATION: თბილისი';
});

test('ლიმიტები: სტუმარი დღეში 3, ანგარიშიანი 5, მთელი საიტი ზედა ზღვარი', async () => {
  raw_clear();
  for (let i = 0; i < 3; i++) assert.equal((await ask('გამარჯობა ' + i)).status, 200);
  const g = await ask('კიდევ'); assert.equal(g.status, 429); assert.match(g.d.error, /დარეგისტრირდი/);
  const u = await reg('599660003');
  for (let i = 0; i < 5; i++) assert.equal((await ask('მე ' + i, u)).status, 200);
  assert.equal((await ask('მეტი', u)).status, 429);
  process.env.AI_GLOBAL_DAILY = '0';
  try { assert.equal((await ask('გამარჯობა', await reg('599660004'))).status, 429); } finally { process.env.AI_GLOBAL_DAILY = '100'; }
});
function raw_clear() { const D = require('better-sqlite3'); const d = new D(dbFile); d.prepare('DELETE FROM ai_usage').run(); d.close(); }
