// ავტომატური ტესტები: npm test
const os = require('os'), path = require('path'), fs = require('fs');
const dbFile = path.join(os.tmpdir(), `t-${process.pid}.sqlite`);
Object.assign(process.env, { DB_FILE: dbFile, DEV_SHOW_CODE: '1', ADMIN_KEY: 'test-admin-key-123456', PREMIUM_MONTHLY_LIMIT: '2', NODE_ENV: 'test', IP_LIMIT: '1000', LOGIN_LIMIT: '1000', SMS_IP_DAILY: '100000', APP_SECRET: 'test-secret-1234567890' });
const test = require('node:test'), assert = require('node:assert/strict');
const Database = require('better-sqlite3');
const app = require('./server');
let server, base, raw;
test.before(() => new Promise((r) => { server = app.listen(0, () => { base = `http://127.0.0.1:${server.address().port}`; raw = new Database(dbFile); r(); }); }));
test.after(() => { server.close(); raw.close(); fs.rmSync(path.join(os.tmpdir(), 'uploads'), { recursive: true, force: true }); for (const f of fs.readdirSync(os.tmpdir())) if (f.startsWith(`t-${process.pid}`)) fs.unlinkSync(path.join(os.tmpdir(), f)); setTimeout(() => process.exit(0), 50); });

function client() {
  const jar = new Map();
  const call = async (method, url, body, headers = {}) => {
    const cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    for (const sc of r.headers.getSetCookie()) { const [kv, ...attrs] = sc.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), v = kv.slice(i + 1); if (/max-age=0|expires=thu, 01 jan 1970/i.test(attrs.join(';')) || v === '') jar.delete(k); else jar.set(k, v); }
    let d = {}; try { d = await r.json(); } catch (_) {}
    return { status: r.status, d };
  };
  const upload = async (kind, buf, ct = 'application/octet-stream') => {
    const cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
    const r = await fetch(base + '/api/media?kind=' + kind, { method: 'POST', headers: { 'Content-Type': ct, ...(cookie ? { Cookie: cookie } : {}) }, body: buf });
    let d = {}; try { d = await r.json(); } catch (_) {}
    return { status: r.status, d };
  };
  return { get: (u, h) => call('GET', u, null, h), post: (u, b, h) => call('POST', u, b, h), put: (u, b) => call('PUT', u, b), del: (u) => call('DELETE', u), upload, jar };
}
const PASS = 'Passw0rd-test';
const regBody = (phone, extra = {}) => ({ role: 'user', name: 'ტესტი', phone, location: 'თბილისი', password: PASS, ...extra });
async function register(phone, extra) {
  const c = client();
  const r = await c.post('/api/auth/register', regBody(phone, extra)); assert.equal(r.status, 200, JSON.stringify(r.d)); assert.match(r.d.devCode, /^\d{6}$/);
  const v = await c.post('/api/auth/register-verify', { phone, code: r.d.devCode }); assert.equal(v.status, 200, JSON.stringify(v.d));
  return c;
}
const login = (phone) => register(phone); // ახალი ანგარიში სესიით (როლი: მომხმარებელი)
const PRO = { role: 'professional', profession: 'ბარბერი', age: 30, experience: '5 წელი', priceMode: 'negotiable' };
const COMPANY = { role: 'company', founded: 2015, activity: 'IT', priceMode: 'fixed', price: '500' };
const admin = (u, b) => client().post(u, b, { 'x-admin-key': 'test-admin-key-123456' });
const order = (n) => ({ service_category: 'სანტექნიკა', order_title: 'შეკვეთა ' + n, order_details: 'დეტალები', location: 'თბილისი', phone: 'HACK' });

test('ცუდი ნომერი და კოდი უარყოფილია', async () => {
  const c = client();
  assert.equal((await c.post('/api/auth/register', regBody('123'))).status, 400);
  const s = await c.post('/api/auth/register', regBody('599000001'));
  assert.equal(s.status, 200);
  assert.equal((await c.post('/api/auth/register-verify', { phone: '599000001', code: '000000' })).status, 400);
  assert.equal((await c.post('/api/auth/register', regBody('599000001'))).status, 429); // 1 წუთის ლიმიტი
  assert.equal((await c.post('/api/auth/register-verify', { phone: '599000001', code: s.d.devCode })).status, 200);
});

test('5 მცდარი ცდის შემდეგ კოდი იბლოკება', async () => {
  const c = client(); const s = await c.post('/api/auth/register', regBody('599000002'));
  const wrong = s.d.devCode === '111111' ? '222222' : '111111';
  for (let i = 0; i < 5; i++) assert.equal((await c.post('/api/auth/register-verify', { phone: '599000002', code: wrong })).status, 400);
  assert.equal((await c.post('/api/auth/register-verify', { phone: '599000002', code: s.d.devCode })).status, 429);
});

test('სესიის გარეშე შეკვეთები დაცულია', async () => {
  const c = client();
  assert.equal((await c.get('/api/orders')).status, 401);
  assert.equal((await c.post('/api/orders', order(0))).status, 401);
});

test('შეკვეთაზე ვერიფიცირებული ნომერი იწერება; არა-VIP დაბლოკილია', async () => {
  const cust = await login('599100001'), std = await login('599100002');
  assert.equal((await cust.post('/api/orders', order(1))).status, 200);
  assert.equal((await cust.post('/api/orders', { ...order(2), service_category: 'არარსებული' })).status, 400);
  assert.equal(raw.prepare("SELECT phone FROM orders WHERE title='შეკვეთა 1'").get().phone, '+995599100001');
  const b = await std.get('/api/orders'); assert.equal(b.d.locked, true); assert.equal(b.d.open >= 1, true); assert.equal(b.d.list, undefined);
  assert.equal((await std.post('/api/orders/1/take')).status, 403);
});

test('VIP: ნომერი იმალება, ერთხელ იღებს, ლიმიტი მოქმედებს', async () => {
  const cust = await login('599200001'), vip = await login('599200002'), vip2 = await login('599200003');
  assert.equal((await client().post('/api/admin/plan', { phone: '599200002', plan: 'premium' })).status, 403);
  assert.equal((await admin('/api/admin/plan', { phone: '599200002', plan: 'premium', days: 30 })).status, 200);
  await admin('/api/admin/plan', { phone: '599200003', plan: 'premium' });
  const ids = [];
  for (let i = 0; i < 3; i++) { await cust.post('/api/orders', order('v' + i)); }
  const board = await vip.get('/api/orders'); assert.equal(board.d.locked, false);
  assert.ok(board.d.open.every((o) => !('phone' in o)), 'ნომერი არ უნდა ჩანდეს');
  const mine = board.d.open.filter((o) => o.title.startsWith('შეკვეთა v')).map((o) => o.id);
  const t1 = await vip.post(`/api/orders/${mine[0]}/take`); assert.equal(t1.status, 200); assert.equal(t1.d.phone, '+995599200001');
  assert.equal((await vip2.post(`/api/orders/${mine[0]}/take`)).status, 409);
  assert.equal((await vip.post(`/api/orders/${mine[1]}/take`)).status, 200);
  assert.equal((await vip.post(`/api/orders/${mine[2]}/take`)).status, 429); // ლიმიტი = 2
  assert.equal((await vip2.post(`/api/orders/${mine[2]}/take`)).status, 200); // სხვას ჯერ აქვს ლიმიტი
});

test('საკუთარი შეკვეთის აღება და ვადაგასული VIP', async () => {
  const u = await login('599300001'); await admin('/api/admin/plan', { phone: '599300001', plan: 'premium', days: 5 });
  await u.post('/api/orders', order('own'));
  const id = raw.prepare("SELECT id FROM orders WHERE title='შეკვეთა own'").get().id;
  assert.equal((await u.post(`/api/orders/${id}/take`)).status, 400);
  raw.prepare("UPDATE users SET plan_until=? WHERE phone='+995599300001'").run(Date.now() - 1000);
  assert.equal((await u.get('/api/orders')).d.locked, true);
  assert.equal((await u.get('/api/me')).d.plan, 'standard');
});

test('კლიენტი ხედავს და აუქმებს საკუთარ ღია შეკვეთას', async () => {
  const c = await login('599400001'), vip = await login('599400002'); await admin('/api/admin/plan', { phone: '599400002', plan: 'unlimited' });
  await c.post('/api/orders', order('c1')); await c.post('/api/orders', order('c2'));
  const list = (await c.get('/api/orders/posted')).d.orders; assert.equal(list.length, 2);
  const [a, b] = list.map((o) => o.id);
  assert.equal((await c.post(`/api/orders/${a}/cancel`)).status, 200);
  assert.equal((await vip.post(`/api/orders/${a}/take`)).status, 409); // გაუქმებული ვერ აიღება
  await vip.post(`/api/orders/${b}/take`);
  assert.equal((await c.post(`/api/orders/${b}/cancel`)).status, 409); // აღებული ვეღარ გაუქმდება
  assert.equal((await vip.post(`/api/orders/${b}/cancel`)).status, 409); // სხვის შეკვეთას ვერ აუქმებს
});

test('ადმინი: გასაღების გარეშე აკრძალულია; მეორე წყაროდან მოთხოვნა დაბლოკილია', async () => {
  assert.equal((await client().get('/api/admin/users')).status, 403);
  assert.equal((await client().get('/api/admin/users', { 'x-admin-key': 'test-admin-key-123456' })).status, 200);
  const c = await login('599500001');
  assert.equal((await c.post('/api/orders', order('evil'), { Origin: 'http://evil.example' })).status, 403);
  assert.equal((await c.post('/api/orders', order('good'), { Origin: base })).status, 200);
});

// ================= ახალი: ანგარიშები, პაროლები, საცდელი პერიოდი =================
const dayMs = 864e5;
const resetSends = (p) => raw.prepare('DELETE FROM sends WHERE phone=?').run('+995' + p); // ტესტში 1-წუთიანი SMS ლიმიტის გვერდის ავლა

test('რეგისტრაცია: სერვერი ამოწმებს მონაცემებს და პაროლი მხოლოდ ჰეშად ინახება', async () => {
  const c = client();
  const bad = async (extra, label) => assert.equal((await c.post('/api/auth/register', regBody('599600001', extra))).status, 400, label);
  await bad({ password: 'short1' }, 'მოკლე პაროლი');
  await bad({ password: 'abcdefghij' }, 'ციფრის გარეშე');
  await bad({ password: '1234567890' }, 'ასოს გარეშე');
  await bad({ role: 'admin' }, 'უცნობი როლი');
  await bad({ name: 'ა' }, 'მოკლე სახელი');
  await bad({ ...PRO, age: 12 }, 'ასაკი');
  await bad({ ...PRO, profession: '###' }, 'პროფესია');
  await bad({ ...COMPANY, founded: 1800 }, 'დაარსების წელი');
  await bad({ ...PRO, priceMode: 'fixed', price: 'უფასო' }, 'ფასი');
  await register('599600002', PRO);
  const row = raw.prepare("SELECT pass_hash FROM users WHERE phone='+995599600002'").get();
  assert.match(row.pass_hash, /^scrypt\$16384\$8\$1\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  assert.ok(!row.pass_hash.includes(PASS), 'პაროლი ღია ტექსტად არ უნდა ინახებოდეს');
});

test('საცდელი პერიოდი: პროფესიონალს და კომპანიას 30 დღე, კლიენტს არა; დუბლიკატი ნომერი უარყოფილია', async () => {
  const pro = await register('599600011', PRO), co = await register('599600012', COMPANY), usr = await register('599600013');
  const near = (ts, days) => Math.abs(ts - (Date.now() + days * dayMs)) < 60e3;
  const q = (p) => raw.prepare('SELECT trial_ends,role FROM users WHERE phone=?').get('+995' + p);
  assert.ok(near(q('599600011').trial_ends, 30)); assert.ok(near(q('599600012').trial_ends, 30)); assert.equal(q('599600013').trial_ends, null);
  const me = (await pro.get('/api/me')).d;
  assert.equal(me.role, 'professional'); assert.equal(me.active, true); assert.equal(me.trial.daysLeft, 30); assert.equal(me.profile.profession, 'ბარბერი');
  assert.equal((await usr.get('/api/me')).d.trial, null);
  assert.equal((await client().post('/api/auth/register', regBody('599600011', PRO))).status, 409);
  assert.equal(typeof (await co.get('/api/me')).d.profile.founded, 'number');
});

test('საცდელი პერიოდის ამოწურვა: შეჩერდება; ფასიანი პაკეტი აქტიურს ხდის', async () => {
  const pro = await register('599600021', PRO);
  raw.prepare("UPDATE users SET trial_ends=? WHERE phone='+995599600021'").run(Date.now() - 1000);
  let me = (await pro.get('/api/me')).d; assert.equal(me.active, false); assert.equal(me.trial.expired, true);
  await admin('/api/admin/plan', { phone: '599600021', plan: 'premium', days: 30 });
  me = (await pro.get('/api/me')).d; assert.equal(me.active, true); assert.equal(me.trial, null);
  raw.prepare("UPDATE users SET plan_until=? WHERE phone='+995599600021'").run(Date.now() - 1000); // პაკეტიც გაუვიდა
  me = (await pro.get('/api/me')).d; assert.equal(me.active, false);
});

test('შესვლა: ახალი მოწყობილობა მოითხოვს SMS-ს, სანდო მოწყობილობა — არა; SMS მარტო საკმარისი არ არის', async () => {
  const phone = '599600031'; await register(phone, PRO);
  const c = client(); // ახალი მოწყობილობა (did ქუქი არ აქვს)
  assert.equal((await c.post('/api/auth/login', { phone, password: 'Wrong-pass1' })).status, 401);
  assert.equal((await c.post('/api/auth/login', { phone: '599699999', password: PASS })).status, 401); // არარსებული ნომერი — იგივე შეტყობინება
  resetSends(phone);
  const l = await c.post('/api/auth/login', { phone, password: PASS }); assert.equal(l.status, 200); assert.equal(l.d.needCode, true);
  assert.equal((await c.get('/api/me')).status, 401, 'კოდამდე სესია არ არსებობს');
  assert.equal((await c.post('/api/auth/login-verify', { code: l.d.devCode === '111111' ? '222222' : '111111' })).status, 400);
  assert.equal((await c.post('/api/auth/login-verify', { code: l.d.devCode })).status, 200);
  assert.equal((await c.get('/api/me')).status, 200);
  await c.post('/api/auth/logout'); assert.equal((await c.get('/api/me')).status, 401);
  const again = await c.post('/api/auth/login', { phone, password: PASS }); assert.equal(again.status, 200); assert.equal(again.d.needCode, undefined, 'სანდო მოწყობილობას SMS აღარ სჭირდება');
  assert.equal((await c.get('/api/me')).status, 200);
  // მხოლოდ SMS-ით (პაროლის გარეშე) შესვლა შეუძლებელია
  resetSends(phone);
  const attacker = client(); const sent = await attacker.post('/api/auth/reset-start', { phone }); // კოდს თავად ბრაუზერი ვერ გამოიყენებს შესვლაზე
  assert.equal((await attacker.post('/api/auth/login-verify', { code: sent.d.devCode })).status, 401);
  assert.equal((await attacker.get('/api/me')).status, 401);
});

test('5 მცდარი პაროლის შემდეგ ანგარიში 15 წუთით იბლოკება', async () => {
  const phone = '599600041'; await register(phone);
  const c = client();
  for (let i = 0; i < 5; i++) assert.equal((await c.post('/api/auth/login', { phone, password: 'Wrong-pass' + i })).status, 401);
  assert.equal((await c.post('/api/auth/login', { phone, password: PASS })).status, 429, 'სწორი პაროლიც კი უარყოფილია ბლოკის დროს');
  raw.prepare("UPDATE users SET locked_until=? WHERE phone='+995599600041'").run(Date.now() - 1000);
  resetSends(phone);
  assert.equal((await c.post('/api/auth/login', { phone, password: PASS })).status, 200);
});

test('პაროლის აღდგენა: ძველი სესიები და მოწყობილობები უქმდება', async () => {
  const phone = '599600051'; const old = await register(phone);
  assert.equal((await old.get('/api/me')).status, 200);
  const none = await client().post('/api/auth/reset-start', { phone: '599699998' }); assert.equal(none.status, 200); assert.equal(none.d.devCode, undefined, 'არარსებული ანგარიში არ ვლინდება');
  resetSends(phone);
  const c = client(); const r = await c.post('/api/auth/reset-start', { phone }); assert.match(r.d.devCode, /^\d{6}$/);
  assert.equal((await c.post('/api/auth/reset-verify', { phone, code: r.d.devCode, password: 'weak' })).status, 400);
  assert.equal((await c.post('/api/auth/reset-verify', { phone, code: r.d.devCode, password: 'New-Passw0rd' })).status, 200);
  assert.equal((await old.get('/api/me')).status, 401, 'ძველი სესია უნდა გაუქმდეს');
  assert.equal((await client().post('/api/auth/login', { phone, password: PASS })).status, 401, 'ძველი პაროლი აღარ მუშაობს');
  resetSends(phone);
  const fresh = await old.post('/api/auth/login', { phone, password: 'New-Passw0rd' }); assert.equal(fresh.status, 200); assert.equal(fresh.d.needCode, true, 'ძველი მოწყობილობა აღარ არის სანდო');
});

test('ადმინის მიერ წინასწარ მინიჭებული პაკეტი რეგისტრაციის შემდეგაც რჩება; დაკავებულ ანგარიშს ვერ გადაიფარავს', async () => {
  await admin('/api/admin/plan', { phone: '599600061', plan: 'premium', days: 60 });
  const c = await register('599600061', PRO);
  const me = (await c.get('/api/me')).d; assert.equal(me.plan, 'premium'); assert.equal(me.role, 'professional'); assert.equal(me.vip, true);
  const r = await client().post('/api/auth/register', regBody('599600061', { name: 'მოტყუებული' })); assert.equal(r.status, 409);
  const adminList = (await client().get('/api/admin/users', { 'x-admin-key': 'test-admin-key-123456' })).d.users.find((u) => u.phone === '+995599600061');
  assert.equal(adminList.role, 'professional'); assert.ok(adminList.trial_ends > Date.now());
});


// ---------- პროფილები და მედია ----------
const JPG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(200, 1)]);
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(100, 2)]);
const MP4 = Buffer.concat([Buffer.from([0, 0, 0, 0x18]), Buffer.from('ftypmp42'), Buffer.alloc(3000, 3)]);
async function getRaw(url, cookieJar) {
  const cookie = cookieJar ? [...cookieJar].map(([k, v]) => `${k}=${v}`).join('; ') : '';
  return fetch(base + url, { headers: cookie ? { Cookie: cookie } : {} });
}

test('პროფილების სია საჯაროა; მხოლოდ პროფესიონალები/კომპანიები; ტელეფონი ჩანს', async () => {
  const pro = await register('599770001', { ...PRO, name: 'ბექო' });
  await register('599770002', { name: 'მომხმარებელი' });
  const r = await client().get('/api/profiles');
  assert.equal(r.status, 200);
  const mine = r.d.profiles.find((p) => p.phone === '+995599770001');
  assert.ok(mine); assert.equal(mine.role, 'professional'); assert.equal(mine.profession, 'ბარბერი');
  assert.equal(r.d.profiles.some((p) => p.phone === '+995599770002'), false);
  assert.equal(r.d.profiles.some((p) => 'pass_hash' in p || 'password' in p), false);
  assert.equal((await client().get('/api/profiles/' + mine.id)).status, 200);
  assert.equal((await client().get('/api/profiles?role=company')).d.profiles.some((p) => p.id === mine.id), false);
});

test('პროფილის რედაქტირება: მხოლოდ საკუთარი, ვალიდაციით', async () => {
  const c = await register('599770003', { ...PRO });
  assert.equal((await client().put('/api/profile', { desc: 'x' })).status, 401);
  const ok = await c.put('/api/profile', { desc: 'კარგი ოსტატი', skills: ['თმა', 'წვერი'], contact: 'fb.com/x', price: '50', priceMode: 'fixed', age: 31 });
  assert.equal(ok.status, 200); assert.equal(ok.d.profile.desc, 'კარგი ოსტატი'); assert.deepEqual(ok.d.profile.skills, ['თმა', 'წვერი']);
  assert.equal((await c.put('/api/profile', { age: 5 })).status, 400);
  assert.equal((await c.put('/api/profile', { priceMode: 'x' })).status, 400);
  assert.equal((await c.put('/api/profile', { name: '' })).status, 400);
  const u = await register('599770004'); // ჩვეულებრივ მომხმარებელს პროფილი არ აქვს
  assert.equal((await u.put('/api/profile', { desc: 'x' })).status, 403);
});

test('ატვირთვა: ფოტო და ავატარი; ტიპი შიგთავსით მოწმდება; პაკეტის ლიმიტი', async () => {
  const c = await register('599770005', { ...PRO });
  const fake = await c.upload('photo', Buffer.from('<html><script>alert(1)</script></html>'), 'image/jpeg');
  assert.equal(fake.status, 415);
  assert.equal((await c.upload('photo', MP4, 'image/jpeg')).status, 415);   // ვიდეო ფოტოდ არ გადის
  assert.equal((await c.upload('photo', Buffer.alloc(0))).status, 411);
  const av = await c.upload('avatar', PNG, 'image/png'); assert.equal(av.status, 201);
  const av2 = await c.upload('avatar', JPG, 'image/jpeg'); assert.equal(av2.status, 201);
  assert.equal(raw.prepare("SELECT COUNT(*) c FROM media WHERE kind='avatar' AND user_id=(SELECT id FROM users WHERE phone='+995599770005')").get().c, 1); // ძველი ავატარი წაიშალა
  for (let i = 0; i < 10; i++) assert.equal((await c.upload('photo', JPG, 'image/jpeg')).status, 201);
  assert.equal((await c.upload('photo', JPG, 'image/jpeg')).status, 403); // სტანდარტი: 10 ფოტო
  for (let i = 0; i < 3; i++) assert.equal((await c.upload('video', MP4, 'video/mp4')).status, 201);
  assert.equal((await c.upload('video', MP4, 'video/mp4')).status, 403); // სტანდარტი: 3 ვიდეო
  const me = (await client().get('/api/profiles')).d.profiles.find((p) => p.phone === '+995599770005');
  assert.equal(me.photos.length, 10); assert.ok(me.avatar.startsWith('/media/'));
  const f = await getRaw(me.photos[0].url);
  assert.equal(f.status, 200); assert.equal(f.headers.get('content-type'), 'image/jpeg'); assert.equal(f.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await getRaw('/media/../../server.js')).status, 404);
  assert.equal((await getRaw('/media/' + 'a'.repeat(32))).status, 404);
});

test('ვიდეო: პრო პაკეტზე ტვირთავს, Range მუშაობს, ზომის ლიმიტი მოქმედებს', async () => {
  const c = await register('599770006', { ...PRO });
  assert.equal((await admin('/api/admin/plan', { phone: '599770006', plan: 'pro' })).status, 200);
  const v = await c.upload('video', MP4, 'video/mp4'); assert.equal(v.status, 201, JSON.stringify(v.d));
  const rr = await fetch(base + v.d.url, { headers: { Range: 'bytes=0-99' } });
  assert.equal(rr.status, 206); assert.equal((await rr.arrayBuffer()).byteLength, 100);
  assert.equal((await c.upload('video', MP4, 'video/mp4')).status, 201);
  assert.equal((await c.upload('video', MP4, 'video/mp4')).status, 403); // პრო: 2 ვიდეო
  const big = await c.upload('photo', Buffer.concat([JPG, Buffer.alloc(9 * 1048576)]), 'image/jpeg');
  assert.equal(big.status, 413); // ფოტო > 8MB
  assert.equal(fs.readdirSync(path.join(path.dirname(dbFile), 'uploads')).some((f) => f.endsWith('.part')), false); // ნარჩენი ფაილი არ რჩება
});

test('წაშლა: მხოლოდ მფლობელი წაშლის', async () => {
  const a = await register('599770007', { ...PRO }), b = await register('599770008', { ...PRO });
  const up = await a.upload('photo', JPG, 'image/jpeg');
  assert.equal((await b.del('/api/media/' + up.d.id)).status, 404);
  assert.equal((await a.del('/api/media/' + up.d.id)).status, 200);
  assert.equal((await getRaw(up.d.url)).status, 404);
});

test('საცდელის ამოწურვის შემდეგ პროფილი და მისი ფაილები სერვერიდან იმალება; გადახდისას ბრუნდება', async () => {
  const c = await register('599770009', { ...PRO });
  const up = await c.upload('photo', JPG, 'image/jpeg');
  const id = (await client().get('/api/profiles')).d.profiles.find((p) => p.phone === '+995599770009').id;
  raw.prepare('UPDATE users SET trial_ends=? WHERE id=?').run(Date.now() - 1000, id);
  assert.equal((await client().get('/api/profiles')).d.profiles.some((p) => p.id === id), false);
  assert.equal((await client().get('/api/profiles/' + id)).status, 404);
  assert.equal((await getRaw(up.d.url)).status, 404);                 // სტუმარი ვერ ხედავს
  assert.equal((await getRaw(up.d.url, c.jar)).status, 200);          // მფლობელი ხედავს
  assert.equal((await admin('/api/admin/plan', { phone: '599770009', plan: 'pro' })).status, 200);
  assert.equal((await client().get('/api/profiles')).d.profiles.some((p) => p.id === id), true);
});

test('პროფილის ფოტო ყველას შეუძლია (მომხმარებელსაც); პორტფოლიო მხოლოდ პროფესიონალს/კომპანიას', async () => {
  const u = await register('599770090', { name: 'კლიენტი' });
  const a = await u.upload('avatar', PNG, 'image/png'); assert.equal(a.status, 201);
  assert.equal((await u.upload('photo', JPG, 'image/jpeg')).status, 403);
  assert.equal((await u.get('/api/me')).d.avatar, a.d.url);
  assert.equal((await getRaw(a.d.url)).status, 200);
  assert.equal((await u.del('/api/media/' + a.d.id)).status, 200);
  assert.equal((await u.get('/api/me')).d.avatar, '');
});

test('რეგისტრაცია მხოლოდ ქართული მობილურით; უცხოური ნომრები უარყოფილია', async () => {
  const c = client();
  for (const bad of ['+4915112345678', '4915112345678', '+12025550123', '0599123456', '599 12 34', '+995322123456', '99532212345', '699123456', '']) {
    const r = await c.post('/api/auth/register', regBody(bad));
    assert.equal(r.status, 400, 'უნდა უარყოფილიყო: ' + bad);
  }
  for (const [i, good] of ['599770101', '+995 599 770 102', '995599770103', '(599) 77-01-04'].entries()) {
    const r = await c.post('/api/auth/register', regBody(good)); assert.equal(r.status, 200, good + ' ' + JSON.stringify(r.d));
  }
  assert.equal(raw.prepare("SELECT COUNT(*) c FROM pending_regs WHERE phone IN ('+995599770101','+995599770102','+995599770103','+995599770104')").get().c, 4);
});

test('SMS-ის დღიური ლიმიტი ერთ IP-ზე (ფულის დაკარგვისგან დაცვა)', async () => {
  const prev = process.env.SMS_IP_DAILY;
  raw.prepare('DELETE FROM sends').run();
  process.env.SMS_IP_DAILY = '3';
  try {
    for (let i = 0; i < 3; i++) assert.equal((await client().post('/api/auth/register', regBody('59977021' + i))).status, 200);
    const r = await client().post('/api/auth/register', regBody('599770219'));
    assert.equal(r.status, 429); assert.match(r.d.error, /დღიური ლიმიტი/);
  } finally { process.env.SMS_IP_DAILY = prev; raw.prepare('DELETE FROM sends').run(); }
});

// ---------- შეფასებები, რჩეულები, ჩატი ----------
async function meId(c) { return (await c.get('/api/me')).d.id; }

test('შეფასებები: სტუმარი ხედავს; ავტორი ერთხელ აფასებს (განახლებადია); საკუთარს ვერ; ვალიდაცია', async () => {
  const pro = await register('599770301', { ...PRO }), cli = await register('599770302', { name: 'კლიენტი' }), cli2 = await register('599770303', { name: 'მეორე' });
  const pid = await meId(pro);
  assert.equal((await client().post('/api/reviews', { targetId: pid, stars: 5 })).status, 401);
  assert.equal((await pro.post('/api/reviews', { targetId: pid, stars: 5 })).status, 403);
  assert.equal((await cli.post('/api/reviews', { targetId: pid, stars: 0 })).status, 400);
  assert.equal((await cli.post('/api/reviews', { targetId: pid, stars: 6 })).status, 400);
  assert.equal((await cli.post('/api/reviews', { targetId: await meId(cli2), stars: 5 })).status, 404); // ჩვეულებრივი მომხმარებელი არ ფასდება
  assert.equal((await cli.post('/api/reviews', { targetId: pid, stars: 4, comment: 'კარგია' })).status, 200);
  assert.equal((await cli.post('/api/reviews', { targetId: pid, stars: 5, comment: 'ძალიან კარგია' })).status, 200); // განახლება, არა დუბლიკატი
  assert.equal((await cli2.post('/api/reviews', { targetId: pid, stars: 3 })).status, 200);
  const list = (await client().get('/api/reviews')).d.reviews.filter((r) => r.targetId === pid);
  assert.equal(list.length, 2);
  const mine = list.find((r) => r.authorName === 'კლიენტი'); assert.equal(mine.stars, 5); assert.equal(mine.comment, 'ძალიან კარგია');
  assert.equal((await cli.del('/api/reviews/' + pid)).d.removed, 1);
  assert.equal((await client().get('/api/reviews')).d.reviews.filter((r) => r.targetId === pid).length, 1);
});

test('შეფასებები: ვადაგასული პროფილის შეფასებები იმალება', async () => {
  const pro = await register('599770304', { ...PRO }), cli = await register('599770305');
  const pid = await meId(pro);
  await cli.post('/api/reviews', { targetId: pid, stars: 5 });
  raw.prepare('UPDATE users SET trial_ends=? WHERE id=?').run(Date.now() - 1000, pid);
  assert.equal((await client().get('/api/reviews')).d.reviews.some((r) => r.targetId === pid), false);
  assert.equal((await cli.post('/api/reviews', { targetId: pid, stars: 4 })).status, 404);
});

test('რჩეულები: მხოლოდ საკუთარი სია, მხოლოდ პროფილები', async () => {
  const pro = await register('599770306', { ...PRO }), co = await register('599770307', { ...COMPANY }), cli = await register('599770308'), other = await register('599770309');
  const [pid, cid] = [await meId(pro), await meId(co)];
  assert.equal((await client().get('/api/favorites')).status, 401);
  assert.equal((await cli.put('/api/favorites/' + pid)).status, 200);
  assert.equal((await cli.put('/api/favorites/' + cid)).status, 200);
  assert.equal((await cli.put('/api/favorites/' + await meId(other))).status, 404);
  assert.equal((await pro.put('/api/favorites/' + pid)).status, 403);
  const f = (await cli.get('/api/favorites')).d.favorites;
  assert.deepEqual(f.map((x) => x.role).sort(), ['company', 'professional']);
  assert.equal((await other.get('/api/favorites')).d.favorites.length, 0);
  await cli.del('/api/favorites/' + pid);
  assert.equal((await cli.get('/api/favorites')).d.favorites.length, 1);
});

test('ჩატი: პროფესიონალს ყველა წერს; ჩვეულებრივ ადამიანს მხოლოდ ვინც მოუწერა; მესამე პირი ვერ კითხულობს', async () => {
  const pro = await register('599770310', { ...PRO }), cli = await register('599770311', { name: 'კლიენტი' }), spy = await register('599770312', { name: 'მესამე' });
  const [pid, cid] = [await meId(pro), await meId(cli)];
  assert.equal((await client().post('/api/messages', { to: pid, text: 'x' })).status, 401);
  assert.equal((await cli.post('/api/messages', { to: await meId(spy), text: 'სპამი' })).status, 403); // ჯერ არ მოუწერია
  assert.equal((await cli.post('/api/messages', { to: pid, text: '   ' })).status, 400);
  assert.equal((await cli.post('/api/messages', { to: cid, text: 'ჩემთვის' })).status, 400);
  assert.equal((await cli.post('/api/messages', { to: pid, text: 'გამარჯობა' })).status, 200);
  assert.equal((await pro.post('/api/messages', { to: cid, text: 'გამარჯობა, გისმენთ' })).status, 200); // პასუხი კლიენტს, რომელმაც მოწერა
  const a = (await cli.get('/api/messages')).d;
  assert.equal(a.messages.length, 2); assert.equal(a.people[0].id, pid);
  const inc = (await cli.get('/api/messages?since=' + a.messages[0].id)).d; assert.equal(inc.messages.length, 1);
  assert.equal((await spy.get('/api/messages')).d.messages.length, 0);
});

test('ჩატი: წუთში 20 შეტყობინების ლიმიტი', async () => {
  const pro = await register('599770313', { ...PRO }), cli = await register('599770314');
  const pid = await meId(pro); let last;
  for (let i = 0; i < 21; i++) last = await cli.post('/api/messages', { to: pid, text: 'm' + i });
  assert.equal(last.status, 429);
});
