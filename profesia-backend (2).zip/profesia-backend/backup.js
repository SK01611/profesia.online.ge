// სრული ასლი: node backup.js
// ქმნის: data-backup-თარიღი.sqlite (ბაზა) და uploads-backup-თარიღი/ (ფოტოები და ვიდეოები)
const path = require('path'), fs = require('fs');
const Database = require('better-sqlite3');
const src = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const uploads = process.env.UPLOAD_DIR || path.join(path.dirname(src), 'uploads');
const day = new Date().toISOString().slice(0, 10);
const dir = process.env.BACKUP_DIR || '.';
fs.mkdirSync(dir, { recursive: true });
const out = path.join(dir, `data-backup-${day}.sqlite`);
new Database(src, { readonly: true }).backup(out).then(() => {
  console.log('ბაზის ასლი შეიქმნა:', out);
  if (fs.existsSync(uploads)) {
    const dst = path.join(dir, `uploads-backup-${day}`);
    fs.cpSync(uploads, dst, { recursive: true, force: true });
    console.log('ფაილების ასლი შეიქმნა:', dst);
  }
}).catch((e) => { console.error(e.message); process.exit(1); });
