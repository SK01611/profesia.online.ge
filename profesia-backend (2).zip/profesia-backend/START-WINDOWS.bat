@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing, please wait...
  call npm install
  if errorlevel 1 ( echo Install failed. Send me the text above. & pause & exit /b 1 )
)
set DEV_SHOW_CODE=1
echo.
echo Open Chrome and go to:  http://localhost:3000
echo Keep this window open while you use the site. Press Ctrl+C to stop.
echo.
start "" http://localhost:3000
node server.js
pause
